#ifndef __TYPE_H__
#define __TYPE_H__
#include <vector>
#include <string>

class Type
{
private:
    int kind;
protected:
    enum {INT, VOID, FUNC, PTR,CONST};
public:
    Type(int kind) : kind(kind) {};
    virtual ~Type() {};
    virtual std::string toStr() = 0;
    bool isInt() const {return kind == INT;};
    bool isVoid() const {return kind == VOID;};
    bool isFunc() const {return kind == FUNC;};
    bool isCons() const {return kind == CONST;};
};

class IntType : public Type
{
private:
    int size;
public:
    IntType(int size) : Type(Type::INT), size(size){};
    std::string toStr();
};

class VoidType : public Type
{
public:
    VoidType() : Type(Type::VOID){};
    std::string toStr();
};

class FunctionType : public Type
{
private:
    Type *returnType;
    std::vector<Type*> paramsType;
    int num;
public:
    FunctionType(Type* returnType, std::vector<Type*> paramsType,int num=0) : 
    Type(Type::FUNC), returnType(returnType), paramsType(paramsType),num(num){};
    std::string toStr();
    Type* getRetType(){return returnType;};
    int getk(){return num;};
};

class PointerType : public Type
{
private:
    Type *valueType;
public:
    PointerType(Type* valueType) : Type(Type::PTR) {this->valueType = valueType;};
    std::string toStr();
};
class ConstType : public Type
{
private:
    int size;
public:
    ConstType(int size) : Type(Type::CONST), size(size){};
    std::string toStr();
};
class TypeSystem
{
private:
    static IntType commonInt;
    static IntType commonBool;
    static VoidType commonVoid;
    static ConstType commonConst;
public:
    static Type *intType;
    static Type *voidType;
    static Type *boolType;
    static Type *constType;
};

class funcnum
{
private:
    int num;
public:
    funcnum(){num=0;};
    void inc(){num++;};
    void zero(){num=0;};
    int getnum(){return num;};
};
static funcnum myone;

class funcpar{
private:
    std::vector<Type*> paramsType;
public:
    funcpar(){paramsType={};};
    void push(Type * k){paramsType.push_back(k);};
    std::vector<Type*> getpar(){return paramsType;};
    void clear(){paramsType.clear();};
};
static funcpar mypar;

class funcuse
{
private:
    int num;
public:
    funcuse(){num=0;};
    void inc(){num++;};
    void zero(){num=0;};
    int getnum(){return num;};
};
static funcuse mytwo;
#endif
